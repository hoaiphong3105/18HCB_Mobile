package com.example.nhom11_tuan5;

public interface FragmentCallbacks {
    void    onMsgFromMainToFragment(String msg);
    void onChangeSelectionFromMainToFragment(int position,int length,Student student);
    void onControlListFromMainToFragment (String controlCode);
}
